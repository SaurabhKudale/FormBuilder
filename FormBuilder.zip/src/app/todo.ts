export class Todo {
    id: number;
    email: string;
    first_name: Date;
}
